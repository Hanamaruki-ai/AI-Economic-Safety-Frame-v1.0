﻿# Commercial Use License
Version 1.0  
Issued: 2025-11-25  
Author: Hanamaruki

---

This license applies to **commercial use** of the following materials  
included in this repository:

- AI Economic Safety Frame v1.0  
- AI Safety × Economic Risk ChatLog Digest

The framework is primarily released under the MIT License.  
This document defines **additional requirements for commercial deployments**.

---

## 1. Definition of Commercial Use

Commercial use includes:

- Integration into enterprise AI products or tools  
- Embedding into Agentic AI safety layers  
- Use in API billing control systems  
- Paid training, consulting, or educational material  
- Adoption into company-wide internal AI guidelines

---

## 2. Conditions for Commercial Use

Commercial users agree to the following:

### (a) Credit Display  
Include the following attribution in product materials or documentation:

> “Based on AI Economic Safety Frame v1.0 (Hanamaruki)”

### (b) Liability Disclaimer  
The author is **not responsible** for any:

- API billing events  
- financial loss  
- legal issues  
- operational incidents  

arising from the use of this framework.

### (c) No False Claims  
You may not present this framework as  
“proprietary technology developed by your company”.

### (d) Redistribution Allowed (MIT-compliant)  
Redistribution is allowed, but the license and attribution must remain.

---

## 3. Prohibited Actions

- Removing attribution  
- Claiming the framework as your company’s original invention  
- Using the framework to fabricate evaluation results  

---

## 4. License Fee

**Version v1.0 is free for all commercial use.**

A different licensing scheme may apply to future enterprise editions (v2.x).

---

## 5. Disclaimer

This license does not guarantee accuracy or safety of implementation.  
All users must perform independent validation and risk assessment.

---

## 6. Contact

For improvements or questions, please open a GitHub Issue.
